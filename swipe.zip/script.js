// import Swiper from 'swiper';
// import 'swiper-bundle.min.css';
// import 'swiper/swiper.min.css';
// import 'swiper/modules/navigation.min.css';
// import 'swiper/modules/pagination.min.css';

const swiper = new Swiper('.swiper', {
  // Optional parameters
  direction: 'vertical',
  loop: true,
  breakpoints: {
    // when window width is >= 320px
    320: {},
    // If we need pagination
    pagination: {
      el: '.swiper-pagination',
    },

    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },

    // And if we need scrollbar
    scrollbar: {
      el: '.swiper-scrollbar',
    },
  },
});
swiper.on('breakpoint', function () {
  swiper.disable();
});
let main = document.querySelector('.main-block');
let review = document.querySelector('.review-block');
let info = document.querySelector('.about-block');
let mainLink = document.querySelector('.header-link');
let reviewLink = document.querySelectorAll('.header-link')[1];
let aboutLink = document.querySelectorAll('.header-link')[2];

console.log(document.querySelector('.main-block'));

mainLink.addEventListener('click', () => {
  main.classList.remove('hide');
  review.classList.add('hide');
  info.classList.add('hide');
});

reviewLink.addEventListener('click', () => {
  main.classList.add('hide');
  review.classList.remove('hide');
  info.classList.add('hide');
});

aboutLink.addEventListener('click', () => {
  main.classList.add('hide');
  review.classList.add('hide');
  info.classList.remove('hide');
});
