# AdaptiveSite

<p>Первый макет с адаптивом</p>
<p>Языки: HTML, CSS.</p>

Для запуска:

```Sh
npm install
npm start
```

git
